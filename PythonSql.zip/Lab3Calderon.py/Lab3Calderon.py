
#Ricardo Calderon
#lab3, transactions database 
#Due Date 10/29/2018
#Submitted 10/23/2018

from urllib.request import urlopen
import sqlite3

#defined a view so that users can see what they have inserted
def view():
    conn = sqlite3.connect("lab3trans.db")
    cur= conn.cursor()
    cur.execute("SELECT * FROM transactions")
    rows=cur.fetchall()
    conn.close()
    return rows
    
#defined a delete function so that user can deelete names from the database
def delete(name):
    conn=sqlite3.connect("lab3trans.db")
    cur= conn.cursor()
    cur.execute("DELETE FROM transactions WHERE name =?",(name,))
    conn.commit()
    conn.close()
    
    

#user inputs a a response whether he wants to insert view or delete   
response = input("What would you like to do?(insert,view,delete):").upper()


#Create transactions table.
if response == "INSERT":
    url = "http://facweb.cdm.depaul.edu/sjost/it212/rates.txt"

    response = urlopen(url)

    line = str(response.read( ))

     

    # Remove first two characters and last character from line

    # This is called slicing

    line = line[2:-1]


    conn = sqlite3.connect('lab3trans.db')

    cur = conn.cursor( )

     
    cur.execute( \

    '''create table if not exists transactions(

        name varchar(10),

        date varchar(10),

        target_currency varchar(3),

        source_amount float,

        target_amount float);

        ''')

    # Read data from keyboard.

    name = input("Enter name: ")

    date = input("Enter date: ")

    target_currency = input("Enter target currency: ")

    source_amount = float(input("Enter source amount: "))

     

     #reads from the online source and seperates value

    items = line.split(";")

    exchange_rate = 0.0

    #this compares the currency between the online source and the user input
    for item in items:

        fields = item.split(",")

        currency_code = fields[0].strip( )

        rate = float(fields[1].strip( ))

        if target_currency == currency_code:

            exchange_rate = rate

            break;

   

    if exchange_rate == 0.0:

        print("Currency is not available!")

        sys.exit( )

     

     

    target_amount = source_amount * exchange_rate

    print("Target amount: " + str(target_amount))


    cur.execute(f'''insert into transactions values(

      '{name}', '{date}', '{target_currency}', {source_amount}, {target_amount} );''')

    # Commit changes.

    conn.commit( )

     

    # Query kids table.

    cur.execute("select * from transactions;")

     

    # Print results from query

    print(cur.fetchall( ))

     

    # Close database.

    conn.close( )
#if user reponse is a view it will show the user the database
elif response == "VIEW":
     print(view())
#if user reponse is a delete then he will be asked what name he would like to delete     
elif response == "DELETE":
    print(view())
    delete_name= input("What name would you like to delete?:")
    delete(delete_name)
    print(view())

    

